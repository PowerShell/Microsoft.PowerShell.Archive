
    Write-Host 'Hello World from Powershell'

